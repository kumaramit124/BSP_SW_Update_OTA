# BSP layer for updating Minnowboard Max with OSTree

OSTree bootloader integration for Minnowboard Max/Turbot. Add it to BBLAYERS when using [meta-updater](https://github.com/advancedtelematic/meta-updater) with [Minnowboard](http://www.elinux.org/Minnowboard:MinnowMax).
